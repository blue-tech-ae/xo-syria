<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Size>
 */
class SizeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        // $value = [
        //     "en" => $this->faker->randomElement(['S','M','L','XL','XX','1*2*3', '4*6*8', '6*8*10*12', '6*12*18*24', '8*10*12*14']),
        //     "ar" => $this->faker->randomElement(['S','M','L','XL','XX','1*2*3', '4*6*8', '6*8*10*12', '6*12*18*24', '8*10*12*14'])
        // ];
        // static  $id=11;
        // return [
        //     'value' => $value,
        //     'sku_code'=> $id++,
        // ];

    }
}
